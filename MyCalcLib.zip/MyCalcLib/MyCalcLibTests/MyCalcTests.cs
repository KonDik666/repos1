﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using MyCalcLib;
using System;

namespace MyCalcLibTests
{
    [TestClass]
    public class MyCalcTests
    {
        /// <summary>
        /// проверка суммы
        /// </summary>
        [TestMethod]
        public void Sum_10and20_30returned()  //проверяем сумму
        {
            //arange
            double x = -10, y = -20;
            double expected = -30;

            //act
            MyCalc c = new MyCalc();
            double actual = c.Sum(x, y);

            //assert
            Assert.AreEqual(expected, actual);
        }

        /// <summary>
        /// проверка разности
        /// </summary>
        [TestMethod]
        public void Subtract_30and20_10returned()   //проверяем разность
        {
            //arange
            double x = 30, y = 20;
            double expected = 10;

            //act
            MyCalc d = new MyCalc();
            double actual = d.Subtract(x, y);

            //assert
            Assert.AreEqual(expected, actual);
        }

        /// <summary>
        /// проверка произведения
        /// </summary>
        [TestMethod]
        public void Multiply_30and20_600returned()   //проверяем произведение
        {
            //arange
            double x = 30.2, y = 20.5;
            double expected = 619.1;

            //act
            MyCalc e = new MyCalc();
            double actual = e.Mult(x, y);

            //assert
            Assert.AreEqual(expected, actual);
        }

        /// <summary>
        /// проверка частного
        /// </summary>

        [TestMethod]
        public void Division_30and10_3returned()   //проверяем частное
        {
            //arange
            double x = 30, y = 10;
            double expected = 3;

            //act
            MyCalc f = new MyCalc();
            double actual = f.Divis(x, y);

            //assert
            Assert.AreEqual(expected, actual);
        }
    }
}
