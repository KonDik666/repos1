﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyCalcLib
{
    public class MyCalc
    {


        /// <summary>
        /// нахождение суммы
        /// </summary>
        /// <param name="x">первое слагаемое</param>
        /// <param name="y">второе слагаемое</param>
        /// <returns>сумма</returns>
        public double Sum(double x, double y)   //
        {
            //if (x < 0 & y<0) { return (x+y)-((x+y)*2); }
           // else { return x + y; }
            return x + y;
        }


        /// <summary>
        /// нахождение разности
        /// </summary>
        /// <param name="x">уменьшаемое</param>
        /// <param name="y">вычитаемое</param>
        /// <returns>разность</returns>
        public double Subtract(double x, double y)
        {

            return x - y;
        }


        /// <summary>
        /// нахождение произведения
        /// </summary>
        /// <param name="x">умножаемое</param>
        /// <param name="y">множитель</param>
        /// <returns>прооизведение</returns>
        public double Mult(double x, double y)
        {
            return x * y;
        }



        /// <summary>
        /// нахождение произведения
        /// </summary>
        /// <param name="x">делимое</param>
        /// <param name="y">делитель</param>
        /// <returns>частное</returns>
        public double Divis(double x, double y)
        {
            if (y == 0) { throw new DivideByZeroException(); }
            else { return x / y; }
            
        }
    }
}
